$('.m-article-page-tips').click(function(){
    $(this).hide().parent().css('paddingTop',30);
})
$('.m-tg').hover(function(){
    $('.m-tg-cont').toggle();
})